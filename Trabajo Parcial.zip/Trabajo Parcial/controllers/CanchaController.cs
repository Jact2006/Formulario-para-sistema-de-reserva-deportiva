﻿using System.Collections.Generic;
using System.Linq;
using Trabajo_Parcial.entities;

namespace Trabajo_Parcial.controllers
{
    internal class CanchaController
    {
        public static List<Cancha> ListaCanchas = new List<Cancha>();

        public void RegistrarCancha(Cancha nuevaCancha)
        {
            //autogeneramos id de cancha
            nuevaCancha.IdCancha = ListaCanchas.Count > 0 ? ListaCanchas.Max(c => c.IdCancha) + 1 : 1;
            ListaCanchas.Add(nuevaCancha);
        }

        public List<Cancha> ObtenerTodas()
        {
            return ListaCanchas;
        }

        public Cancha ObtenerPorId(int id)
        {
            return ListaCanchas.FirstOrDefault(c => c.IdCancha == id);
        }

        public bool EditarCancha(int id, string nuevoNombre, TipoDeporte nuevoDeporte, decimal nuevaTarifa, bool nuevoEstado)
        {
            var chancha = ListaCanchas.FirstOrDefault(c => c.IdCancha == id);
            if (chancha != null)
            {
                chancha.Nombre = nuevoNombre;
                chancha.Deporte = nuevoDeporte;
                chancha.TarifaBase = nuevaTarifa;
                chancha.EstadoMantenimiento = nuevoEstado;
                return true;
            }
            return false;
        }

        public bool EliminarCancha(int id)
        {
            var cancha = ListaCanchas.FirstOrDefault(c => c.IdCancha == id);
            if (cancha != null)
            {
                // Antes de eliminar, verificar si hay reservas activas para esta cancha
                bool tieneReservasActivas = ReservaController.ListaReservas.Any(r =>
                    r.CanchaAsignada.IdCancha == id && r.Estado != EstadoReserva.Cancelada);
                if (!tieneReservasActivas)
                {
                    ListaCanchas.Remove(cancha);
                    return true; // Eliminación exitosa
                }
            }
            return false; // No se pudo eliminar (cancha no encontrada o tiene reservas activas)
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Trabajo_Parcial.entities;

namespace Trabajo_Parcial.controllers
{
    internal class ClienteController
    {
        public static List<Cliente> ListaClientes = new List<Cliente>();
        public bool RegistrarCliente(Cliente nuevoCliente)
        {
            // Validamos que no exista otro cliente con el mismo DNI
            if (ListaClientes.Any(c => c.DNI == nuevoCliente.DNI))
            {
                return false;
            }
            ListaClientes.Add(nuevoCliente);
            return true;
        }

        public List<Cliente> ObtenerTodos()
        {
            return ListaClientes;
        }

        public bool EditarCliente(string dni, string nuevoNombre, string nuevoTelefono, bool nuevoEstadoMoroso)
        {
            var cliente = ListaClientes.FirstOrDefault(c => c.DNI == dni);
            if (cliente != null)
            {
                cliente.NombreCompleto = nuevoNombre;
                cliente.Telefono = nuevoTelefono;
                cliente.EstadoMoroso = nuevoEstadoMoroso;
                return true;
            }
            return false;
        }

        public bool EliminarCliente(string dni)
        {
            var cliente = ListaClientes.FirstOrDefault(c => c.DNI == dni);
            if (cliente != null)
            {
                ListaClientes.Remove(cliente);
                return true;
            }
            return false;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Trabajo_Parcial.entities;

namespace Trabajo_Parcial.controllers
{
    internal class ReservaController
    {
        public static List<Reserva> ListaReservas = new List<Reserva>();

        public bool ValidarDisponibilidad(int idCancha, DateTime fecha, TimeSpan inicio, TimeSpan fin)
        {
            bool hayCruce = ListaReservas.Any(r =>
                r.CanchaAsignada.IdCancha == idCancha &&
                r.FechaReserva.Date == fecha.Date &&
                ((inicio >= r.HoraInicio && inicio < r.HoraFin) ||
                 (fin > r.HoraInicio && fin <= r.HoraFin) ||
                 (inicio <= r.HoraInicio && fin >= r.HoraFin))
            );
            return !hayCruce; 
        }

        public bool RegistrarReserva(Reserva nuevaReserva)
        {
            if (ValidarDisponibilidad(nuevaReserva.CanchaAsignada.IdCancha, nuevaReserva.FechaReserva, nuevaReserva.HoraInicio, nuevaReserva.HoraFin))
            {
                nuevaReserva.IdReserva = ListaReservas.Count > 0 ? ListaReservas.Max(r => r.IdReserva) + 1 : 1;
                nuevaReserva.Estado = EstadoReserva.Confirmada;
                ListaReservas.Add(nuevaReserva);
                return true; //reserva registrada exitosamente
            }
            return false; //no se pudo registrar la reserva por cruce de horarios
        }

        public List<Reserva> ObtenerTodas()
        {
            return ListaReservas;
        }

        public bool ReprogramarReserva(int idReserva, DateTime nuevaFecha, TimeSpan nuevoInicio, TimeSpan nuevoFin, int idCancha)
        {
            bool hayCruce = ListaReservas.Any(r =>
                r.IdReserva != idReserva && // Ignoramos la reserva actual para que no choque consigo misma
                r.CanchaAsignada.IdCancha == idCancha &&
                r.FechaReserva.Date == nuevaFecha.Date &&
                r.Estado != EstadoReserva.Cancelada &&
                ((nuevoInicio >= r.HoraInicio && nuevoInicio < r.HoraFin) ||
                 (nuevoFin > r.HoraInicio && nuevoFin <= r.HoraFin) ||
                 (nuevoInicio <= r.HoraInicio && nuevoFin >= r.HoraFin))
            );

            if (!hayCruce)
            {
                var reserva = ListaReservas.FirstOrDefault(r => r.IdReserva == idReserva);
                if (reserva != null)
                {
                    reserva.FechaReserva = nuevaFecha;
                    reserva.HoraInicio = nuevoInicio;
                    reserva.HoraFin = nuevoFin;
                    // Actualizamos la cancha por si decidió cambiarla
                    reserva.CanchaAsignada = CanchaController.ListaCanchas.FirstOrDefault(c => c.IdCancha == idCancha);
                    return true;
                }
            }
            return false; 
        }

        public bool CancelarReserva(int idReserva)
        {
            var reserva = ListaReservas.FirstOrDefault(r => r.IdReserva == idReserva);
            if (reserva != null && reserva.Estado != EstadoReserva.Cancelada)
            {
                reserva.Estado = EstadoReserva.Cancelada;
                return true; //reserva cancelada exitosamente
            }
            return false; //no se pudo cancelar la reserva (no encontrada o ya cancelada)
        }
    }
}

﻿using System.Collections.Generic;
using System.Linq;
using Trabajo_Parcial.entities;

namespace Trabajo_Parcial.controllers
{
    internal class AuthController
    {
        public static List<Usuario> ListaUsuarios = new List<Usuario>();

        //Constructor que se ejecuta solo una vez al iniciar la app
        static AuthController()
        {
            // Agregar un usuario admin por defecto
            ListaUsuarios.Add(new Usuario
            {
                IdUsuario = 1,
                Username = "admin",
                PasswordHash = "admin123", // En un sistema real, esto debería ser un hash seguro
                Rol = RolUsuario.Administrador
            });
        }

        //Metodo que se llamara desde el boton Ingresar en  FrmLogin
        public Usuario ValidarCredenciales(string username, string password)
        {
            //Buscar si existe algun usuario con esas credenciales
            var usuarioEncontrado = ListaUsuarios.FirstOrDefault(u =>
                u.Username == username &&
                u.PasswordHash == password);

            //si lo encuentra devuelve al usuario, sino devuelve null
            return usuarioEncontrado;
        }

        public bool RegistrarUsuario(Usuario nuevoUsuario)
        {
            //verificar que el username no exista ya
            if (ListaUsuarios.Any(u => u.Username.ToLower() == nuevoUsuario.Username.ToLower()))
            {
                return false; //no se puede registrar un usuario con un username ya existente
            }

            nuevoUsuario.IdUsuario = ListaUsuarios.Count > 0 ? ListaUsuarios.Max(u => u.IdUsuario) + 1 : 1;

            ListaUsuarios.Add(nuevoUsuario);
            return true; //registro exitoso
        }

        public List<Usuario> ObtenerTodosLosUsuarios()
        {
            return ListaUsuarios;
        }

        public bool RegistrarAdmin(string username, string password)
        {
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                return false; // No se pueden registrar usuarios con campos vacíos
            }
            Usuario nuevoAdmin = new Usuario
            {
                Username = username,
                PasswordHash = password,
                Rol = RolUsuario.Administrador
            };
            return RegistrarUsuario(nuevoAdmin);
        }

        public bool RegistrarRecepcionista(string username, string password)
        {
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                return false; // No se pueden registrar usuarios con campos vacíos
            }
            Usuario nuevoRecepcionista = new Usuario
            {
                Username = username,
                PasswordHash = password,
                Rol = RolUsuario.Recepcionista
            };
            return RegistrarUsuario(nuevoRecepcionista);
        }

        public bool EliminarUsuario(int idUsuario)
        {
            var usuarioEliminar = ListaUsuarios.FirstOrDefault(u => u.IdUsuario == idUsuario);
            if (usuarioEliminar != null)
            {
                int cantidadAdmins = ListaUsuarios.Count(u => u.Rol == RolUsuario.Administrador);
                if (cantidadAdmins <= 1)
                {
                    return false; //no puede existir sistema sin un admin
                }

                ListaUsuarios.Remove(usuarioEliminar);
                return true; //usuario eliminado exitosamente
            }
            return false; //no se encontró el usuario para eliminar
        }

        public bool ModificarUsuario(int idUsuario, string nuevoUsername, string nuevaPassword, RolUsuario nuevoRol)
        {
            var usuarioModificar = ListaUsuarios.FirstOrDefault(u => u.IdUsuario == idUsuario);
            if (usuarioModificar != null)
            {
                //verificar que el nuevo username no exista ya en otro usuario
                if (ListaUsuarios.Any(u => u.Username.ToLower() == nuevoUsername.ToLower() && u.IdUsuario != idUsuario))
                {
                    return false; //no se puede modificar a un username ya existente en otro usuario
                }

                if (usuarioModificar.Rol == RolUsuario.Administrador && nuevoRol != RolUsuario.Administrador)
                {
                    int cantidadAdmins = ListaUsuarios.Count(u => u.Rol == RolUsuario.Administrador);
                    if (cantidadAdmins <= 1)
                    {
                        return false; //no puede existir sistema sin un admin
                    }
                }
                usuarioModificar.Username = nuevoUsername;

                if (!string.IsNullOrWhiteSpace(nuevaPassword))
                {
                    usuarioModificar.PasswordHash = nuevaPassword;
                }

                usuarioModificar.Rol = nuevoRol;

                return true; //usuario modificado exitosamente
            }
            return false; //no se encontró el usuario para modificar
        }
    }
}

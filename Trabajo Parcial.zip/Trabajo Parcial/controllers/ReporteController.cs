﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Trabajo_Parcial.entities;

namespace Trabajo_Parcial.controllers
{
    internal class ReporteController
    {
        //RF05
        //Retornar las reservas de una fecha especifica
        public List<Reserva> GenerarReporteOcupacion(DateTime fechaFiltro)
        {
            return ReservaController.ListaReservas
                .Where(r => r.FechaReserva.Date == fechaFiltro.Date && r.Estado != EstadoReserva.Cancelada)
                .OrderBy(r => r.HoraInicio)
                .ToList();
        }

        //RF06
        //Retornar cuanto dinero se genero en un rango de fechas
        public decimal CalcularIngresos(DateTime inicio, DateTime fin)
        {
            return ReservaController.ListaReservas
                .Where(r => r.FechaReserva.Date >= inicio.Date && 
                       r.FechaReserva.Date <= fin.Date && 
                       r.Estado == EstadoReserva.Finalizada)
                //el calculo de ingresos se hace multiplicando la duracion de la reserva por la tarifa
                //base de la cancha
                .Sum(r => (decimal)r.CalcularDuracionHoras() * r.CanchaAsignada.TarifaBase);
        }

        //RF07
        //Agrupar las reservas por canchas y cuenta cuantas tiene cada una
        public object ObtenerCanchasMasSolicitadas()
        { 
            var ranking = ReservaController.ListaReservas
                .Where(r => r.Estado != EstadoReserva.Cancelada)
                .GroupBy(r => r.CanchaAsignada.Nombre)
                .Select(grupo => new 
                { 
                    Cancha = grupo.Key,
                    TotalReservas = grupo.Count(),
                    HorasAlquiladas = grupo.Sum(r => r.CalcularDuracionHoras())
                })
                .OrderByDescending(x => x.TotalReservas)
                .ToList();

            return ranking; //Retorna objetct para cargar directo al DataGrid
        }
        
        //RF08
        //Reporte de clientes frecuentes
        public object ObtenerClientesFrecuentes()
        {
            var clientes = ReservaController.ListaReservas
                .Where(r => r.Estado != EstadoReserva.Cancelada)
                .GroupBy(r => r.ClienteAsignado.NombreCompleto)
                .Select(grupo => new 
                { 
                    Cliente = grupo.Key,
                    CantidadReservas = grupo.Count()
                })
                .OrderByDescending(x => x.CantidadReservas)
                .Take(10) //tomamos los 10 clientes mas frecuentes
                .ToList();

            return clientes;
        }
    }
}

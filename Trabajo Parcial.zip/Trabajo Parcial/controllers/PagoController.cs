﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Trabajo_Parcial.entities;

namespace Trabajo_Parcial.controllers
{
    internal class PagoController
    {
        public static List<Pago> ListaPagos = new List<Pago>();

        //registrar un nuevo pago en el sistema
        public bool ProcesarPago(Pago nuevoPago)
        {
            if (nuevoPago == null || nuevoPago.ReservaAsociada == null)
            {
                return false; //no se puede procesar un pago sin reserva asociada
            }

            //Autogenerar id
            nuevoPago.IdPago = ListaPagos.Count > 0 ? ListaPagos.Max(p => p.IdPago) + 1 : 1;
            nuevoPago.FechaPago = DateTime.Now;
            nuevoPago.Estado = "Pagado"; //asumimos que el pago se procesa exitosamente

            ListaPagos.Add(nuevoPago);

            //cada vez que pagan, verificamos si esta al dia
            ActualizarEstadoMorosoCliente(nuevoPago.ReservaAsociada.ClienteAsignado.DNI);
            return true;
        }

        //determinar si un cliente debe dinero
        public void ActualizarEstadoMorosoCliente(string dniCliente)
        {
            //buscamos todas las reservas del cliente
            var reservasDelCliente = ReservaController.ListaReservas
                .Where(r => r.ClienteAsignado.DNI == dniCliente &&
                            r.Estado == EstadoReserva.Confirmada &&
                            r.FechaReserva > DateTime.Now)
                .ToList();

            //buscamos cuantos pagos ha realizado el cliente
            var pagosDelCliente = ListaPagos
                .Where(p => p.ReservaAsociada.ClienteAsignado.DNI == dniCliente && p.Estado == "Pagado")
                .ToList();

            //si tienen mas reservas pasadas que pagos registrados, es moroso
            bool debeDinero = reservasDelCliente.Count > pagosDelCliente.Count;

            //actualizamos el estado del cliente
            var cliente = reservasDelCliente.FirstOrDefault()?.ClienteAsignado;
            if (cliente != null)
            {
                cliente.EstadoMoroso = debeDinero;
            }
        }

        //RF08
        public object ObtenerClientesMorosos()
        {
            return ReservaController.ListaReservas
                .Where(r => r.ClienteAsignado.EstadoMoroso)
                .Select(r => new
                {
                    DNI = r.ClienteAsignado.DNI,
                    Cliente = r.ClienteAsignado.NombreCompleto,
                    Telefono = r.ClienteAsignado.Telefono,
                    Deuda = "Pendiente de pago"
                })
                .Distinct()
                .ToList();
        }

        public bool EditarPago(int idPago, string nuevoMetodo, DateTime nuevaFecha)
        {
            var pago = ListaPagos.FirstOrDefault(p => p.IdPago == idPago);
            if (pago != null)
            {
                pago.MetodoPago = nuevoMetodo;
                pago.FechaPago = nuevaFecha;
                return true;
            }
            return false;
        }

        public bool EliminarPago(int idPago)
        {
            var pago = ListaPagos.FirstOrDefault(p => p.IdPago == idPago);
            if (pago != null)
            {
                string dniCliente = pago.ReservaAsociada.ClienteAsignado.DNI;
                ListaPagos.Remove(pago);

                // Al eliminar un pago, recalculamos si el cliente vuelve a ser moroso
                ActualizarEstadoMorosoCliente(dniCliente);
                return true;
            }
            return false;
        }

        public List<Pago> ObtenerTodos()
        {
            return ListaPagos;
        }
    }
}

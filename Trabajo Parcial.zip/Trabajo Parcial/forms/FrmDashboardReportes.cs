﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Trabajo_Parcial.controllers;

namespace Trabajo_Parcial.forms
{
    public partial class FrmDashboardReportes : Form
    {
        private ReporteController _reporteController;
        public FrmDashboardReportes()
        {
            InitializeComponent();
            _reporteController = new ReporteController();
        }

        private void FrmDashboardReportes_Load(object sender, EventArgs e)
        {
            dtpFechaInicio.Value = DateTime.Today;
            dtpFechaFin.Value = DateTime.Today;

            //formato a los DGV
            ConfigurarGrilla(dgIngresosGenerados);
            ConfigurarGrilla(dgRankingCanchas);
            ConfigurarGrilla(dgClientesFrecuentes);
        }
        private void btnGenerarReporte_Click(object sender, EventArgs e)
        {
            DateTime fechaInicio = dtpFechaInicio.Value.Date;
            DateTime fechaFin = dtpFechaFin.Value.Date;

            if (fechaFin < fechaInicio)
            {
                MessageBox.Show("La fecha de fin no puede ser anterior a la fecha de inicio.", "Error de fechas", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //DG Ingresos Generados
            decimal totalIngresos = _reporteController.CalcularIngresos(fechaInicio, fechaFin);
            dgIngresosGenerados.DataSource = new List<object> {
                new
                {
                    Rango_Fechas = $"{fechaInicio:dd/MM/yyyy} al {fechaFin:dd/MM/yyyy}",
                    Total_Recaudado = $"S/. {totalIngresos:0.00}"
                }
            };

            //DG Ranking de Canchas
            dgRankingCanchas.DataSource = _reporteController.ObtenerCanchasMasSolicitadas();


            //DG Clientes Frecuentes
            dgClientesFrecuentes.DataSource = _reporteController.ObtenerClientesFrecuentes();
        }

        private void ConfigurarGrilla(DataGridView dg)
        {
            if (dg != null)
            {
                dg.AllowUserToAddRows = false;
                dg.AllowUserToDeleteRows = false;
                dg.ReadOnly = true;
                dg.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                dg.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                dg.RowHeadersVisible = false;
            }
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

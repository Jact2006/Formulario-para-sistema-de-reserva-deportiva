﻿using System;
using System.Windows.Forms;
using Trabajo_Parcial.entities;
using Trabajo_Parcial.forms;

namespace Trabajo_Parcial
{
    public partial class FrmPrincipal : Form
    {
        private RolUsuario _rolActual;
        public FrmPrincipal(RolUsuario rol)
        {
            InitializeComponent();
            this._rolActual = rol;
            ConfigurarAccesoSegunRol();
        }

        private void ConfigurarAccesoSegunRol()
        {
            lblRol.Text = $"Rol: {this._rolActual}";
            //si el rol es recepcionista, ocultamos los botones de gestion de usuarios y reportes
            if (this._rolActual == RolUsuario.Recepcionista)
            {  
                btnReportes.Visible = false;
                btnReportes.Enabled = false;
            }
        }
        private void btnGestionReservas_Click(object sender, EventArgs e)
        {
            FrmNuevaReserva frm = new FrmNuevaReserva();
            frm.Show();
        }

        private void btnGestionClientes_Click(object sender, EventArgs e)
        {
            ClienteForm frm = new ClienteForm();
            frm.Show();
        }

        private void btnGestionCanchas_Click(object sender, EventArgs e)
        {
            FrmGestionCanchas frm = new FrmGestionCanchas();
            frm.Show();
        }

        private void btnGestionPagos_Click(object sender, EventArgs e)
        {
            GestionDePagos frm = new GestionDePagos();
            frm.Show();
        }

        private void btnReportes_Click(object sender, EventArgs e)
        {
            FrmDashboardReportes frm = new FrmDashboardReportes();
            frm.Show();
        }

        private void btnGestionUsuarios_Click(object sender, EventArgs e)
        {
            FrmGestionUsuarios frm = new FrmGestionUsuarios();
            frm.Show();
        }

        private void btnCerrarSesion_Click(object sender, EventArgs e)
        {
            FrmLogin frmLogin = new FrmLogin();
            frmLogin.Show();
            this.Close();
        }
    }
}

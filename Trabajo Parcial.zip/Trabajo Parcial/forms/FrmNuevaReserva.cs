﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Trabajo_Parcial.controllers;
using Trabajo_Parcial.entities;

namespace Trabajo_Parcial.forms
{
    public partial class FrmNuevaReserva : Form
    {
        private ReservaController reservaController = new ReservaController();
        private ClienteController clienteController = new ClienteController();
        private CanchaController canchaController = new CanchaController();

        public FrmNuevaReserva()
        {
            InitializeComponent();

            if (CanchaController.ListaCanchas.Count == 0)
            {
                CanchaController.ListaCanchas.Add(new Cancha { IdCancha = 1, Nombre = "Las Palmas", Deporte = TipoDeporte.Futbol, TarifaBase = 50 });
                CanchaController.ListaCanchas.Add(new Cancha { IdCancha = 2, Nombre = "Portal", Deporte = TipoDeporte.Tenis, TarifaBase = 30 });
            }

            if (ClienteController.ListaClientes.Count == 0)
            {
                ClienteController.ListaClientes.Add(new Cliente { DNI = "80574582", NombreCompleto = "Juan Pérez", Telefono = "987654321", EstadoMoroso = false });
            }

            // 2. Vinculamos las listas directamente a los ComboBox usando .ToList() para refrescar la vista
            cbSeleccionarCancha.DataSource = CanchaController.ListaCanchas.ToList();
            cbSeleccionarCancha.DisplayMember = "Nombre";
            cbSeleccionarCancha.ValueMember = "IdCancha";

            cbSeleccionarCliente.DataSource = ClienteController.ListaClientes.ToList();
            cbSeleccionarCliente.DisplayMember = "NombreCompleto";
            cbSeleccionarCliente.ValueMember = "DNI";
            // 3. Configuramos los formatos de hora
            dtpHoraInicio.Format = DateTimePickerFormat.Time;
            dtpHoraInicio.ShowUpDown = true;
            dtpHoraFin.Format = DateTimePickerFormat.Time;
            dtpHoraFin.ShowUpDown = true;

            // 4. Cargamos la tabla
            MostrarEnDataGrid();
        }

        private void MostrarEnDataGrid()
        {
            dgReservas.DataSource = null;
            var lista = reservaController.ObtenerTodas();

            if (lista.Count > 0)
            {
                // solo datos que queremos mostrar
                var listaVista = lista.Select(r => new
                {
                    IdReserva = r.IdReserva,
                    Cliente = r.ClienteAsignado.NombreCompleto,
                    Cancha = r.CanchaAsignada.Nombre,
                    Fecha = r.FechaReserva.ToString("dd/MM/yyyy"),
                    Inicio = r.HoraInicio.ToString(@"hh\:mm"),
                    Fin = r.HoraFin.ToString(@"hh\:mm"),
                    Estado = r.Estado.ToString()
                }).ToList();

                dgReservas.DataSource = listaVista;
            }
        }
        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            if (cbSeleccionarCliente.SelectedValue == null || cbSeleccionarCancha.SelectedValue == null)
            {
                MessageBox.Show("Debe seleccionar un cliente y una cancha.");
                return;
            }

            // Validar que la hora de inicio sea menor a la hora de fin
            if (dtpHoraInicio.Value.TimeOfDay >= dtpHoraFin.Value.TimeOfDay)
            {
                MessageBox.Show("La hora de inicio debe ser menor a la hora de fin.");
                return;
            }

            // recuperacion de objetos seleccionados en los ComboBox
            string dniSeleccionado = cbSeleccionarCliente.SelectedValue.ToString();
            int idCanchaSeleccionada = Convert.ToInt32(cbSeleccionarCancha.SelectedValue);

            Cliente clienteObj = clienteController.ObtenerTodos().FirstOrDefault(c => c.DNI == dniSeleccionado);
            Cancha canchaObj = canchaController.ObtenerTodas().FirstOrDefault(c => c.IdCancha == idCanchaSeleccionada);

            Reserva reserva = new Reserva()
            {
                FechaReserva = dtpFechaReserva.Value.Date,
                HoraInicio = dtpHoraInicio.Value.TimeOfDay,
                HoraFin = dtpHoraFin.Value.TimeOfDay,
                ClienteAsignado = clienteObj,
                CanchaAsignada = canchaObj
            };

            bool registrado = reservaController.RegistrarReserva(reserva);

            if (!registrado)
            {
                MessageBox.Show("¡Cruce de horarios! La cancha ya está reservada en ese lapso.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            MessageBox.Show("Reserva registrada con éxito");
            MostrarEnDataGrid();
        }

        private void btnReprogramar_Click(object sender, EventArgs e)
        {
            if (dgReservas.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione una reserva");
                return;
            }

            if (dtpHoraInicio.Value.TimeOfDay >= dtpHoraFin.Value.TimeOfDay)
            {
                MessageBox.Show("La hora de inicio debe ser menor a la hora de fin.");
                return;
            }

            int idReserva = Convert.ToInt32(dgReservas.SelectedRows[0].Cells["IdReserva"].Value);
            DateTime nuevaFecha = dtpFechaReserva.Value.Date;
            TimeSpan nuevoInicio = dtpHoraInicio.Value.TimeOfDay;
            TimeSpan nuevoFin = dtpHoraFin.Value.TimeOfDay;
            int idCancha = Convert.ToInt32(cbSeleccionarCancha.SelectedValue);
            bool reprogramado = reservaController.ReprogramarReserva(idReserva, nuevaFecha, nuevoInicio, nuevoFin, idCancha);

            if (reprogramado)
            {
                MessageBox.Show("Reserva reprogramada con éxito.");
                MostrarEnDataGrid();
            }
            else
            {
                MessageBox.Show("No se pudo reprogramar. Verifique que no haya cruce de horarios.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void brnCancelar_Click(object sender, EventArgs e)
        {
            if (dgReservas.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione una reserva");
                return;
            }

            int idReserva = Convert.ToInt32(dgReservas.SelectedRows[0].Cells["IdReserva"].Value);

            DialogResult dialogResult = MessageBox.Show("¿Está seguro de cancelar esta reserva?", "Confirmar", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                bool cancelado = reservaController.CancelarReserva(idReserva);
                if (cancelado)
                {
                    MessageBox.Show("La reserva ha sido cancelada.");
                    MostrarEnDataGrid();
                }
            }
        }

        private void dgReservas_SelectionChanged(object sender, EventArgs e)
        {
            if (dgReservas.SelectedRows.Count > 0)
            {
                var fila = dgReservas.SelectedRows[0];
                int idReserva = Convert.ToInt32(fila.Cells["IdReserva"].Value);

                // Buscamos la reserva original para setear los combos
                var reserva = reservaController.ObtenerTodas().FirstOrDefault(r => r.IdReserva == idReserva);
                if (reserva != null)
                {
                    cbSeleccionarCliente.SelectedValue = reserva.ClienteAsignado.DNI;
                    cbSeleccionarCancha.SelectedValue = reserva.CanchaAsignada.IdCancha;
                    dtpFechaReserva.Value = reserva.FechaReserva;

                    // Asignar las horas (los TimeSpan deben convertirse a DateTime para el control)
                    dtpHoraInicio.Value = DateTime.Today.Add(reserva.HoraInicio);
                    dtpHoraFin.Value = DateTime.Today.Add(reserva.HoraFin);
                }
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Trabajo_Parcial.controllers;
using Trabajo_Parcial.entities;
using Trabajo_Parcial.forms;

namespace Trabajo_Parcial
{
    public partial class ClienteForm : Form
    {
        private ClienteController clienteController = new ClienteController();
        public ClienteForm()
        {
            InitializeComponent();
        }

        private void ClienteForm_Load(object sender, EventArgs e)
        {
            // Llenamos el combo de estado moroso
            cbEstadoMoroso.Items.Add("No (Al día)");
            cbEstadoMoroso.Items.Add("Sí (Debe dinero)");
            cbEstadoMoroso.SelectedIndex = 0; // Por defecto no es moroso

            // Mostramos los datos iniciales
            MostrarEnDataGrid(clienteController.ObtenerTodos());
        }

        private void MostrarEnDataGrid(List<Cliente> lista)
        {
            // limpiamos la lista
            dgClientes.DataSource = null;
            // validar si hay elementos a mostrar
            if (lista.Count > 0)
            {
                dgClientes.DataSource = lista;
            }
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            if (tbDniCliente.Text == "" || tbNombreCompleto.Text == "" || tbTelefono.Text == "" || cbEstadoMoroso.Text == "")
            {
                MessageBox.Show("Ingrese todos los campos");
                return;
            }

            Cliente cliente = new Cliente()
            {
                DNI = tbDniCliente.Text,
                NombreCompleto = tbNombreCompleto.Text,
                Telefono = tbTelefono.Text,
                EstadoMoroso = cbEstadoMoroso.SelectedIndex == 1 // Si elige la opción 1 ("Sí"), es true
            };

            bool registrado = clienteController.RegistrarCliente(cliente);
            if (!registrado)
            {
                MessageBox.Show("El DNI ya se encuentra registrado");
                return;
            }

            MessageBox.Show("Cliente registrado con éxito");

            // Limpiamos cajas
            tbDniCliente.Text = "";
            tbNombreCompleto.Text = "";
            tbTelefono.Text = "";
            cbEstadoMoroso.SelectedIndex = 0;

            MostrarEnDataGrid(clienteController.ObtenerTodos());
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (dgClientes.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione un cliente");
                return;
            }

            string dni = tbDniCliente.Text; // Usamos el DNI como identificador
            string nombre = tbNombreCompleto.Text;
            string telefono = tbTelefono.Text;
            bool estadoMoroso = cbEstadoMoroso.SelectedIndex == 1;

            bool modificado = clienteController.EditarCliente(dni, nombre, telefono, estadoMoroso);

            if (modificado)
            {
                MessageBox.Show("Cliente modificado");
                MostrarEnDataGrid(clienteController.ObtenerTodos());
            }
            else
            {
                MessageBox.Show("No se encontró el cliente o no se pudo modificar");
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgClientes.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione un cliente");
                return;
            }

            // obtener DNI del cliente seleccionado en la grilla
            var fila = dgClientes.SelectedRows[0];
            string dni = fila.Cells["DNI"].Value.ToString();

            bool eliminado = clienteController.EliminarCliente(dni);
            if (eliminado)
            {
                MessageBox.Show("Cliente eliminado");

                // Limpiamos las cajas
                tbDniCliente.Text = "";
                tbNombreCompleto.Text = "";
                tbTelefono.Text = "";
                cbEstadoMoroso.SelectedIndex = 0;

                MostrarEnDataGrid(clienteController.ObtenerTodos());
            }
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgClientes_SelectionChanged(object sender, EventArgs e)
        {
            if (dgClientes.SelectedRows.Count > 0)
            {
                // tomar la primera fila seleccionada
                var fila = dgClientes.SelectedRows[0];

                tbDniCliente.Text = fila.Cells["DNI"].Value.ToString();
                tbNombreCompleto.Text = fila.Cells["NombreCompleto"].Value.ToString();
                tbTelefono.Text = fila.Cells["Telefono"].Value.ToString();

                bool esMoroso = Convert.ToBoolean(fila.Cells["EstadoMoroso"].Value);
                cbEstadoMoroso.SelectedIndex = esMoroso ? 1 : 0;
            }
        }
    }
}

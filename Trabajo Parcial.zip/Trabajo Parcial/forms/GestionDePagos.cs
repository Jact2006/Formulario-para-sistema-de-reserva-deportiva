﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Trabajo_Parcial.controllers;
using Trabajo_Parcial.entities;

namespace Trabajo_Parcial
{
    public partial class GestionDePagos : Form
    {
        private PagoController pagoController = new PagoController();
        private ReservaController reservaController = new ReservaController();

        public GestionDePagos()
        {
            InitializeComponent();
            ConfigurarFormulario();
        }

        private void ConfigurarFormulario()
        {
            // cargamos las reservas que no estén canceladas
            var reservasActivas = reservaController.ObtenerTodas()
                                    .Where(r => r.Estado != EstadoReserva.Cancelada)
                                    .ToList();

            if (reservasActivas.Count > 0)
            {
                cbSeleccionarReserva.DataSource = reservasActivas;
            
                cbSeleccionarReserva.Format += (s, e) => {
                    var r = (Reserva)e.ListItem;
                    e.Value = $"Reserva #{r.IdReserva} - {r.CanchaAsignada.Nombre} ({r.FechaReserva:dd/MM})";
                };
            }

          
            cbMetodoPago.Items.Clear();
            cbMetodoPago.Items.AddRange(new string[] { "Yape", "Plin", "Efectivo", "BCP" });
            cbMetodoPago.SelectedIndex = 0;

            MostrarEnDataGrid(pagoController.ObtenerTodos());
        }

        private void MostrarEnDataGrid(List<Pago> lista)
        {
            dgPagos.DataSource = null;
            if (lista.Count > 0)
            {
                dgPagos.DataSource = lista.Select(p => new {
                    IdPago = p.IdPago,
                    Reserva = $"#{p.ReservaAsociada.IdReserva}",
                    Cliente = p.ReservaAsociada.ClienteAsignado.NombreCompleto,
                    Monto = $"S/. {p.MontoAbonado:0.00}",
                    Metodo = p.MetodoPago,
                    Fecha = p.FechaPago.ToString("dd/MM/yyyy")
                }).ToList();
            }
        }

        private void btnProcesarPago_Click(object sender, EventArgs e)
        {
            if (cbSeleccionarReserva.SelectedItem == null || tbMonto.Text == "")
            {
                MessageBox.Show("Seleccione una reserva válida.");
                return;
            }

            Pago nuevoPago = new Pago()
            {
                ReservaAsociada = (Reserva)cbSeleccionarReserva.SelectedItem,
                MontoAbonado = Convert.ToDecimal(tbMonto.Text),
                MetodoPago = cbMetodoPago.Text,
                FechaPago = dtpFechaPago.Value.Date
            };

            if (pagoController.ProcesarPago(nuevoPago))
            {
                MessageBox.Show("¡Pago procesado con éxito!");
                MostrarEnDataGrid(pagoController.ObtenerTodos());
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cbSeleccionarReserva_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbSeleccionarReserva.SelectedItem is Reserva seleccionada)
            {
                tbNombreCliente.Text = seleccionada.ClienteAsignado.NombreCompleto;

                double horas = seleccionada.CalcularDuracionHoras();
                decimal montoCalculado = (decimal)horas * seleccionada.CanchaAsignada.TarifaBase;

                tbMonto.Text = montoCalculado.ToString("0.00");
            }
        }

        private void dgPagos_SelectionChanged(object sender, EventArgs e)
        {
            if (dgPagos.SelectedRows.Count > 0)
            {
                var fila = dgPagos.SelectedRows[0];
                tbNombreCliente.Text = fila.Cells["Cliente"].Value.ToString();
                tbMonto.Text = fila.Cells["Monto"].Value.ToString().Replace("S/. ", "");
                cbMetodoPago.Text = fila.Cells["Metodo"].Value.ToString();
            }
        }
    }
}

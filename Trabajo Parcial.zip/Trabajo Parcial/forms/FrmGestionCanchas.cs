﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Trabajo_Parcial.controllers;
using Trabajo_Parcial.entities;

namespace Trabajo_Parcial.forms
{
    public partial class FrmGestionCanchas : Form
    {
        private CanchaController canchaController = new CanchaController();

        public FrmGestionCanchas()
        {
            InitializeComponent();
        }

        private void FrmGestionCanchas_Load(object sender, EventArgs e)
        {
            cbTipoDeporte.DataSource = Enum.GetValues(typeof(TipoDeporte));

            cbEstadoMantenimiento.Items.Add("Disponible");
            cbEstadoMantenimiento.Items.Add("En Mantenimiento");
            cbEstadoMantenimiento.SelectedIndex = 0;

            // Mostramos los datos iniciales
            MostrarEnDataGrid(canchaController.ObtenerTodas());
        }

        private void MostrarEnDataGrid(List<Cancha> lista)
        {
            // limpiamos la lista
            dgCanchas.DataSource = null;
            // validar si hay elementos a mostrar
            if (lista.Count > 0)
            {
                dgCanchas.DataSource = lista;
            }
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            if (tbNombreCancha.Text == "" || tbTarifaBase.Text == "" || cbTipoDeporte.Text == "" || cbEstadoMantenimiento.Text == "")
            {
                MessageBox.Show("Ingrese todos los campos");
                return;
            }

            Cancha cancha = new Cancha()
            {
                Nombre = tbNombreCancha.Text,
                Deporte = (TipoDeporte)cbTipoDeporte.SelectedItem,
                TarifaBase = Convert.ToDecimal(tbTarifaBase.Text),
                EstadoMantenimiento = cbEstadoMantenimiento.Text == "En Mantenimiento"
            };

            canchaController.RegistrarCancha(cancha);
            MessageBox.Show("Cancha registrada con éxito");

            // Limpiamos cajas
            tbNombreCancha.Text = "";
            tbTarifaBase.Text = "";

            MostrarEnDataGrid(canchaController.ObtenerTodas());
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (dgCanchas.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione una cancha");
                return;
            }

            // obtener ID de la cancha seleccionada en la grilla
            var fila = dgCanchas.SelectedRows[0];
            int idCancha = Convert.ToInt32(fila.Cells["IdCancha"].Value);

            string nombre = tbNombreCancha.Text;
            TipoDeporte deporte = (TipoDeporte)cbTipoDeporte.SelectedItem;
            decimal tarifa = Convert.ToDecimal(tbTarifaBase.Text);
            bool estado = cbEstadoMantenimiento.Text == "En Mantenimiento";

            bool modificado = canchaController.EditarCancha(idCancha, nombre, deporte, tarifa, estado);

            if (modificado)
            {
                MessageBox.Show("Cancha modificada");
                MostrarEnDataGrid(canchaController.ObtenerTodas());
            }
            else
            {
                MessageBox.Show("No se encontró la cancha");
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgCanchas.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione una cancha");
                return;
            }

            var fila = dgCanchas.SelectedRows[0];
            int idCancha = Convert.ToInt32(fila.Cells["IdCancha"].Value);

            bool eliminado = canchaController.EliminarCancha(idCancha);
            if (eliminado)
            {
                MessageBox.Show("Cancha eliminada");

                // Limpiamos las cajas porque el registro ya no existe
                tbNombreCancha.Text = "";
                tbTarifaBase.Text = "";

                MostrarEnDataGrid(canchaController.ObtenerTodas());
            }
        }

        private void dgCanchas_SelectionChanged(object sender, EventArgs e)
        {
            if (dgCanchas.SelectedRows.Count > 0)
            {
                // tomar la primera fila seleccionada
                var fila = dgCanchas.SelectedRows[0];

                tbNombreCancha.Text = fila.Cells["Nombre"].Value.ToString();
                tbTarifaBase.Text = fila.Cells["TarifaBase"].Value.ToString();
                cbTipoDeporte.SelectedItem = (TipoDeporte)fila.Cells["Deporte"].Value;

                bool enMantenimiento = Convert.ToBoolean(fila.Cells["EstadoMantenimiento"].Value);
                cbEstadoMantenimiento.Text = enMantenimiento ? "En Mantenimiento" : "Disponible";
            }
        }
    }
}

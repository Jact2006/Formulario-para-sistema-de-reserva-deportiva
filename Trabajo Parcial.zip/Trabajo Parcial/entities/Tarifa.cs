﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trabajo_Parcial.entities
{
    internal class Tarifa
    {
        public int IdTarifa { get; set; }
        public string TipoDia { get; set; }
        public string Turno { get; set; }
        public decimal MultiplicadorPrecio { get; set; }
    }
}

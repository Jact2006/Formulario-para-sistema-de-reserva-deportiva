﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trabajo_Parcial.entities
{
    //Enumeracion para mantener datos controlados y limpios
    public enum TipoDeporte
    {
        Futbol,
        Tenis,
        Voley
    }

    public enum EstadoReserva
    { 
        Pendiente,
        Confirmada,
        Cancelada,
        Finalizada
    }

    public enum RolUsuario
    {
        Administrador,
        Recepcionista
    }
    internal class Enums
    {
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trabajo_Parcial.entities
{
    internal class Pago
    {
        public int IdPago { get; set; }
        public Reserva ReservaAsociada { get; set; }
        public decimal MontoAbonado { get; set; }
        public DateTime FechaPago { get; set; }
        public string MetodoPago { get; set; } //Yape, Plin, etc
        public string Estado { get; set; } //Pagado, pendiente, devuelto
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trabajo_Parcial.entities
{
    internal class Reserva
    {
        public int IdReserva { get; set; }
        public DateTime FechaReserva { get; set; }
        public TimeSpan HoraInicio { get; set; }
        public TimeSpan HoraFin { get; set; }


        //Relacion con otras clases
        public Cliente ClienteAsignado { get; set; }
        public Cancha CanchaAsignada { get; set; }
        public EstadoReserva Estado { get; set; }

        //Metodo para calcular cuantas goras dura la reserva
        public double CalcularDuracionHoras()
        {
            return (HoraFin - HoraInicio).TotalHours;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trabajo_Parcial.entities
{
    internal class Cliente
    {
        public string DNI {  get; set; }
        public string NombreCompleto { get; set; }
        public string Telefono { get; set; }
        public bool EstadoMoroso { get; set; } //true si debe dinero
    }
}

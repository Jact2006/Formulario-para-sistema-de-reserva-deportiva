﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trabajo_Parcial.entities
{
    internal class Cancha
    {
        public int IdCancha { get; set; }
        public string Nombre { get; set; }
        public TipoDeporte Deporte { get; set; }
        public decimal TarifaBase { get; set; }
        public bool EstadoMantenimiento { get; set; }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trabajo_Parcial.entities
{
    internal class Usuario
    {
        public int IdUsuario { get; set; }
        public string Username { get; set; }
        public string PasswordHash { get; set; }
        public RolUsuario Rol { get; set; }

        public bool CambiarPassword(string nuevaClave)
        {
            this.PasswordHash = nuevaClave;
            return true;
        }
    }
}
